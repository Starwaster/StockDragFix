Prevents resource mass from being used in drag force calculations. 
Does not attempt to implement realistic drag nor replace stock aerodynamics. 
With this plugin, vessels will no longer have insane amounts of drag applied against them. 
When used with Real Solar System, rockets no longer require unrealistic amounts of Delta V.